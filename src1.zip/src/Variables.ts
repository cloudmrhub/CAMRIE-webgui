

const CAMRIE_URL= import.meta.env.VITE_CAMRIE_URL

export const DATAAPI = `${CAMRIE_URL}/readdata`;


export const JOBSAPI = `${CAMRIE_URL}/downloads`;
